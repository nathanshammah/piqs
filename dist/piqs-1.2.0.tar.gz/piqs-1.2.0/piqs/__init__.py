from piqs.dicke import *
from piqs.cy.dicke import jmm1_dictionary
from piqs.about import *
from piqs.cite import *

__version__ = '1.0'
